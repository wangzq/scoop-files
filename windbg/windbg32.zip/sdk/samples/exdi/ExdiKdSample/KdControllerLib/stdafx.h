//----------------------------------------------------------------------------
//
// stdafx.h
//
// The headers referenced in this file will be precompiled.
//
// Copyright (c) Microsoft. All rights reserved.
//
//----------------------------------------------------------------------------

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>

#include <Windows.h>
#include <assert.h>
